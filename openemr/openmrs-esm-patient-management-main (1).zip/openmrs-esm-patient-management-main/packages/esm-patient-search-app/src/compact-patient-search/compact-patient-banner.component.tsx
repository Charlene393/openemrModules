import React, { forwardRef, useContext, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import classNames from 'classnames';
import { useTranslation } from 'react-i18next';
import { Tag } from '@carbon/react';
import {
  age,
  ConfigurableLink,
  ExtensionSlot,
  getPatientName,
  interpolateString,
  PatientPhoto,
  useConfig,
} from '@openmrs/esm-framework';
import type { FHIRIdentifier, FHIRPatientType, Identifier, SearchedPatient } from '../types';
import { type PatientSearchConfig } from '../config-schema';
import { PatientSearchContext } from '../patient-search-context';
import styles from './compact-patient-banner.scss';

interface ClickablePatientContainerProps {
  children: React.ReactNode;
  patient: SearchedPatient;
}

interface CompactPatientBannerProps {
  patients: Array<SearchedPatient>;
}

interface IdentifierTagProps {
  identifier: Identifier;
}

const CompactPatientBanner = forwardRef<HTMLDivElement, CompactPatientBannerProps>(({ patients }, ref) => {
  const config = useConfig<PatientSearchConfig>();
  const { t } = useTranslation();

  const getGender = (gender: string) => {
    switch (gender) {
      case 'M':
        return t('male', 'Male');
      case 'F':
        return t('female', 'Female');
      case 'O':
        return t('other', 'Other');
      case 'U':
        return t('unknown', 'Unknown');
      default:
        return gender;
    }
  };

  const fhirPatients: Array<FHIRPatientType> = useMemo(() => {
    // TODO: If/When the online patient search is migrated to the FHIR API at some point, this could
    // be removed. In fact, it could maybe be done at this point already, but doing it when the
    // search returns FHIR objects is much simpler because the code which uses the `fhirPatients`
    // doesn't have to be touched then.
    return patients.map((patient) => {
      const preferredAddress = patient.person.addresses?.find((address) => address.preferred);
      return {
        id: patient.uuid,
        name: [
          {
            id: uuidv4(), // not used
            given: [patient.person.personName.givenName, patient.person.personName.middleName],
            family: patient.person.personName.familyName,
            text: patient.person.personName.display,
          },
        ],
        gender: patient.person.gender,
        birthDate: patient.person.birthdate,
        deceasedDateTime: patient.person.deathDate,
        deceasedBoolean: patient.person.dead,
        identifier: patient.identifiers as unknown as Array<FHIRIdentifier>,
        address: preferredAddress
          ? [
              {
                id: uuidv4(), // not used
                city: preferredAddress.cityVillage,
                country: preferredAddress.country,
                postalCode: preferredAddress.postalCode,
                state: preferredAddress.stateProvince,
                use: 'home',
              },
            ]
          : [],
        telecom: patient.attributes?.filter((attribute) => attribute.attributeType.display == 'Telephone Number'),
      };
    });
  }, [patients]);

  return (
    <div ref={ref}>
      {fhirPatients.map((patient, index) => {
        const preferredIdentifier = patients[index].identifiers.find((identifier) => identifier.preferred);

        const configuredIdentifiers = patients[index].identifiers.filter(
          (identifier) =>
            !identifier.preferred && config.defaultIdentifierTypes.includes(identifier.identifierType.uuid),
        );

        const patientIdentifiers = preferredIdentifier
          ? [preferredIdentifier, ...configuredIdentifiers]
          : configuredIdentifiers;

        const patientName = getPatientName(patient);

        return (
          <ClickablePatientContainer key={patient.id} patient={patients[index]}>
            <div className={styles.patientAvatar} role="img">
              <PatientPhoto patientUuid={patient.id} patientName={patientName}  />
            </div>
            <div>
              <div className={styles.flexRow}>
                <h2 className={styles.patientName}>{patientName}</h2>
                <ExtensionSlot
                  name="patient-banner-tags-slot"
                  state={{ patient, patientUuid: patient.id }}
                  className={styles.flexRow}
                />
              </div>
              <div className={styles.demographics}>
                {getGender(patient.gender)} <span className={styles.middot}>&middot;</span>{' '}
                {patient.birthDate && age(patient.birthDate)}
                <span className={styles.middot}>&middot;</span>
                {patientIdentifiers.map((identifier) => (
                  <IdentifierTag key={identifier.uuid} identifier={identifier} />
                ))}
              </div>
            </div>
          </ClickablePatientContainer>
        );
      })}
    </div>
  );
});

const ClickablePatientContainer = ({ patient, children }: ClickablePatientContainerProps) => {
  const { nonNavigationSelectPatientAction, patientClickSideEffect } = useContext(PatientSearchContext);
  const config = useConfig<PatientSearchConfig>();
  const isDeceased = Boolean(patient?.person?.deathDate);

  if (nonNavigationSelectPatientAction) {
    return (
      <button
        className={classNames(styles.patientSearchResult, styles.patientSearchResultButton, {
          [styles.deceased]: isDeceased,
        })}
        key={patient.uuid}
        onClick={() => {
          nonNavigationSelectPatientAction(patient.uuid);
          patientClickSideEffect?.(patient.uuid);
        }}>
        {children}
      </button>
    );
  } else {
    return (
      <ConfigurableLink
        className={classNames(styles.patientSearchResult, {
          [styles.deceased]: isDeceased,
        })}
        key={patient.uuid}
        onBeforeNavigate={() => patientClickSideEffect?.(patient.uuid)}
        to={interpolateString(config.search.patientChartUrl, {
          patientUuid: patient.uuid,
        })}>
        {children}
      </ConfigurableLink>
    );
  }
};

const IdentifierTag: React.FC<IdentifierTagProps> = ({ identifier }) => {
  return (
    <>
      <Tag size="sm" className={styles.configuredTag} type="warm-gray">
        {identifier.identifierType.display}
      </Tag>
      <span className={styles.configuredLabel}>{identifier.identifier}</span>
    </>
  );
};

export default CompactPatientBanner;
