import React from 'react';
import { vi, describe, it, expect, beforeEach } from 'vitest';
import { renderHook, waitFor } from '@testing-library/react';
import { SWRConfig } from 'swr';
import { type FetchResponse, openmrsFetch, restBaseUrl } from '@openmrs/esm-framework';
import { usePatientAppointments } from './patient-appointments.resource';

const mockOpenmrsFetch = vi.mocked(openmrsFetch);

const wrapper = ({ children }: { children: React.ReactNode }) => (
  <SWRConfig
    value={{
      dedupingInterval: 0,
      provider: () => new Map(),
      revalidateOnFocus: false,
      shouldRetryOnError: false,
    }}>
    {children}
  </SWRConfig>
);

describe('usePatientAppointments', () => {
  let abortController: AbortController;

  beforeEach(() => {
    abortController = new AbortController();
    mockOpenmrsFetch.mockReset();
    mockOpenmrsFetch.mockResolvedValue({ data: [] } as FetchResponse);
  });

  it('fetches separately when both patientUuid and startDate change', async () => {
    const pastDate = new Date('2020-01-01').getTime();
    mockOpenmrsFetch
      .mockResolvedValueOnce({ data: [] } as FetchResponse)
      .mockResolvedValueOnce({ data: [{ status: 'Scheduled', startDateTime: pastDate }] } as FetchResponse);

    const { rerender, result } = renderHook(
      ({ patientUuid, startDate }) => usePatientAppointments(patientUuid, startDate, abortController),
      {
        wrapper,
        initialProps: {
          patientUuid: 'patient-1',
          startDate: '2026-04-01',
        },
      },
    );

    await waitFor(() => expect(mockOpenmrsFetch).toHaveBeenCalledTimes(1));
    expect(mockOpenmrsFetch).toHaveBeenNthCalledWith(
      1,
      `${restBaseUrl}/appointments/search`,
      expect.objectContaining({
        method: 'POST',
        body: expect.objectContaining({
          patientUuid: 'patient-1',
          startDate: '2026-04-01',
        }),
      }),
    );
    expect(result.current.data?.pastAppointments).toBeUndefined();

    rerender({ patientUuid: 'patient-2', startDate: '2026-04-02' });

    await waitFor(() => expect(mockOpenmrsFetch).toHaveBeenCalledTimes(2));
    expect(mockOpenmrsFetch).toHaveBeenNthCalledWith(
      2,
      `${restBaseUrl}/appointments/search`,
      expect.objectContaining({
        method: 'POST',
        body: expect.objectContaining({
          patientUuid: 'patient-2',
          startDate: '2026-04-02',
        }),
      }),
    );
    // Data must reflect patient-2's response, not patient-1's cached empty data
    await waitFor(() => expect(result.current.data?.pastAppointments).toHaveLength(1));
  });

  it('triggers a new fetch and returns fresh data when only patientUuid changes', async () => {
    // patient-1 returns empty; patient-2 returns one past appointment
    const pastDate = new Date('2020-01-01').getTime();
    mockOpenmrsFetch
      .mockResolvedValueOnce({ data: [] } as FetchResponse)
      .mockResolvedValueOnce({ data: [{ status: 'Scheduled', startDateTime: pastDate }] } as FetchResponse);

    const { rerender, result } = renderHook(
      ({ patientUuid, startDate }) => usePatientAppointments(patientUuid, startDate, abortController),
      {
        wrapper,
        initialProps: { patientUuid: 'patient-1', startDate: '2026-04-01' },
      },
    );

    await waitFor(() => expect(mockOpenmrsFetch).toHaveBeenCalledTimes(1));
    // patient-1 has no past appointments
    expect(result.current.data?.pastAppointments).toBeUndefined();

    // Change only the patient – startDate remains '2026-04-01'
    rerender({ patientUuid: 'patient-2', startDate: '2026-04-01' });

    await waitFor(() => expect(mockOpenmrsFetch).toHaveBeenCalledTimes(2));
    expect(mockOpenmrsFetch).toHaveBeenNthCalledWith(
      2,
      `${restBaseUrl}/appointments/search`,
      expect.objectContaining({
        body: expect.objectContaining({ patientUuid: 'patient-2', startDate: '2026-04-01' }),
      }),
    );
    // Result must reflect patient-2's data, not patient-1's cached empty data
    await waitFor(() => expect(result.current.data?.pastAppointments).toHaveLength(1));
  });

  it('triggers a new fetch when only startDate changes', async () => {
    const pastDate = new Date('2020-01-01').getTime();
    mockOpenmrsFetch
      .mockResolvedValueOnce({ data: [] } as FetchResponse)
      .mockResolvedValueOnce({ data: [{ status: 'Scheduled', startDateTime: pastDate }] } as FetchResponse);

    const { rerender, result } = renderHook(
      ({ patientUuid, startDate }) => usePatientAppointments(patientUuid, startDate, abortController),
      {
        wrapper,
        initialProps: { patientUuid: 'patient-1', startDate: '2026-04-01' },
      },
    );

    await waitFor(() => expect(mockOpenmrsFetch).toHaveBeenCalledTimes(1));
    expect(mockOpenmrsFetch).toHaveBeenNthCalledWith(
      1,
      `${restBaseUrl}/appointments/search`,
      expect.objectContaining({
        body: expect.objectContaining({ patientUuid: 'patient-1', startDate: '2026-04-01' }),
      }),
    );
    expect(result.current.data?.pastAppointments).toBeUndefined();

    // Change only the startDate – patientUuid remains 'patient-1'
    rerender({ patientUuid: 'patient-1', startDate: '2026-04-15' });

    await waitFor(() => expect(mockOpenmrsFetch).toHaveBeenCalledTimes(2));
    expect(mockOpenmrsFetch).toHaveBeenNthCalledWith(
      2,
      `${restBaseUrl}/appointments/search`,
      expect.objectContaining({
        body: expect.objectContaining({ patientUuid: 'patient-1', startDate: '2026-04-15' }),
      }),
    );
    // Data must reflect the new date's response, not the first date's cached data
    await waitFor(() => expect(result.current.data?.pastAppointments).toHaveLength(1));
  });

  it('places an appointment occurring later today in todaysAppointments only, not in upcomingAppointments', async () => {
    // Later today is after `now` but still today, so it must not leak into the "upcoming" (future days) list.
    const laterToday = new Date().setHours(23, 0, 0, 0);
    mockOpenmrsFetch.mockResolvedValue({
      data: [{ uuid: 'later-today', status: 'Scheduled', startDateTime: laterToday }],
    } as FetchResponse);

    const { result } = renderHook(() => usePatientAppointments('patient-1', '2026-04-01', abortController), {
      wrapper,
    });

    await waitFor(() => expect(result.current.data?.todaysAppointments).toHaveLength(1));
    expect(result.current.data?.upcomingAppointments).toHaveLength(0);
  });

  it('places an appointment on a future day in upcomingAppointments', async () => {
    const futureDate = new Date(new Date().setDate(new Date().getDate() + 2)).getTime();
    mockOpenmrsFetch.mockResolvedValue({
      data: [{ uuid: 'future', status: 'Scheduled', startDateTime: futureDate }],
    } as FetchResponse);

    const { result } = renderHook(() => usePatientAppointments('patient-1', '2026-04-01', abortController), {
      wrapper,
    });

    await waitFor(() => expect(result.current.data?.upcomingAppointments).toHaveLength(1));
    expect(result.current.data?.todaysAppointments).toHaveLength(0);
  });

  it('does not fetch again when patientUuid and startDate are unchanged (cache hit)', async () => {
    const { rerender } = renderHook(
      ({ patientUuid, startDate }) => usePatientAppointments(patientUuid, startDate, abortController),
      {
        wrapper,
        initialProps: { patientUuid: 'patient-1', startDate: '2026-04-01' },
      },
    );

    await waitFor(() => expect(mockOpenmrsFetch).toHaveBeenCalledTimes(1));

    // Rerender with identical inputs – SWR key is unchanged, must serve from cache
    rerender({ patientUuid: 'patient-1', startDate: '2026-04-01' });

    // Flush pending microtasks then assert no second fetch was triggered
    await waitFor(() => {});
    expect(mockOpenmrsFetch).toHaveBeenCalledTimes(1);
  });
});
