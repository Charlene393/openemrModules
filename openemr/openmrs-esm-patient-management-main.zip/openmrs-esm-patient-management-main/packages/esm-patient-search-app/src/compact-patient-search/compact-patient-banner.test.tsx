import React from 'react';
import { vi, describe, it, expect, test, beforeEach } from 'vitest';
import dayjs from 'dayjs';
import { render, screen } from '@testing-library/react';
import { getDefaultsFromConfigSchema, restBaseUrl, useConfig } from '@openmrs/esm-framework';
import { type SearchedPatient } from '../types';
import { configSchema, type PatientSearchConfig } from '../config-schema';
import { PatientSearchContext } from '../patient-search-context';
import CompactPatientBanner from './compact-patient-banner.component';

// The virtualizer measures a 0px scroll element under happy-dom, so it would render no rows.
// Stub it to render every row, letting the result assertions run.
vi.mock('@tanstack/react-virtual', () => ({
  useVirtualizer: ({ count }: { count: number }) => ({
    getVirtualItems: () =>
      Array.from({ length: count }, (_, index) => ({ index, key: index, start: index * 90, size: 90 })),
    getTotalSize: () => count * 90,
    scrollToIndex: () => {},
    measureElement: () => {},
    isScrolling: false,
  }),
}));

const mockUseConfig = vi.mocked(useConfig<PatientSearchConfig>);

const birthdate = '1990-01-01T00:00:00.000+0000';
const age = dayjs().diff(birthdate, 'years');
const patients: Array<SearchedPatient> = [
  {
    attributes: [],
    identifiers: [
      {
        display: 'OpenMRS ID = 1000NLY',
        uuid: '19e98c23-d26f-4668-8810-00da0e10e326',
        identifier: '1000NLY',
        identifierType: {
          uuid: '05a29f94-c0ed-11e2-94be-8c13b969e334',
          display: 'OpenMRS ID',
          links: [
            {
              rel: 'self',
              uri: `http://dev3.openmrs.org/openmrs/${restBaseUrl}/patientidentifiertype/05a29f94-c0ed-11e2-94be-8c13b969e334`,
              resourceAlias: 'patientidentifiertype',
            },
          ],
        },
        location: {
          uuid: '44c3efb0-2583-4c80-a79e-1f756a03c0a1',
          display: 'Outpatient Clinic',
        },
        preferred: true,
      },
    ],
    person: {
      age,
      addresses: [],
      birthdate,
      dead: false,
      deathDate: null,
      gender: 'M',
      personName: {
        display: 'Smith, John Doe',
        givenName: 'John',
        middleName: 'Doe',
        familyName: 'Smith',
      },
    },
    uuid: 'test-patient-uuid',
  },
];

describe('CompactPatientBanner', () => {
  beforeEach(() => mockUseConfig.mockReturnValue(getDefaultsFromConfigSchema(configSchema)));

  it('renders a compact patient banner', () => {
    render(
      <PatientSearchContext.Provider value={{}}>
        <CompactPatientBanner patients={patients} />
      </PatientSearchContext.Provider>,
    );

    // TODO: Restore these tests once we improve the patient banner test stubs
    // expect(
    //   screen.getByRole('link', { name: new RegExp(`Smith, John Doe Male · ${age} yrs · OpenMRS ID 1000NLY`, 'i') }),
    // ).toBeInTheDocument();
    // expect(screen.getByRole('link')).toHaveAttribute('href', `/openmrs/spa/patient/${patients[0].uuid}/chart/`);
    expect(screen.getByText('Patient Photo')).toBeInTheDocument();
    // expect(screen.getByRole('heading', { name: /Smith, John Doe/ })).toBeInTheDocument();
  });

  it('handles an array of valid patients', () => {
    const multiplePatients: Array<SearchedPatient> = [
      ...patients,
      {
        ...patients[0],
        uuid: 'test-patient-uuid-2',
        person: {
          ...patients[0].person,
          personName: {
            display: 'Doe, Jane',
            givenName: 'Jane',
            middleName: '',
            familyName: 'Doe',
          },
        },
      },
    ];

    render(
      <PatientSearchContext.Provider value={{}}>
        <CompactPatientBanner patients={multiplePatients} />
      </PatientSearchContext.Provider>,
    );

    expect(screen.getAllByText('Patient Photo')).toHaveLength(2);
  });

  it('renders empty state when patients array is empty', () => {
    render(
      <PatientSearchContext.Provider value={{}}>
        <CompactPatientBanner patients={[]} />
      </PatientSearchContext.Provider>,
    );

    expect(screen.queryByText('Patient Photo')).not.toBeInTheDocument();
  });
});
