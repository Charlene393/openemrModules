import React, { forwardRef, useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { InlineLoading, Layer, Tile } from '@carbon/react';
import { EmptyCardIllustration } from '@openmrs/esm-framework';
import CompactPatientBanner, { type CompactPatientBannerHandle } from './compact-patient-banner.component';
import Loader from './loader.component';
import type { PatientSearchResponse } from '../types';
import styles from './patient-search.scss';

const RecentlySearchedPatients = forwardRef<CompactPatientBannerHandle, PatientSearchResponse>(
  ({ data: searchResults, fetchError, hasMore, isLoading, isValidating, setPage }, ref) => {
    const { t } = useTranslation();

    const fetchMore = useCallback(() => setPage((page) => page + 1), [setPage]);

    if (!searchResults && isLoading) {
      return (
        <div className={styles.searchResultsContainer} role="progressbar">
          {[...Array(5)].map((_, index) => (
            <Loader key={index} />
          ))}
        </div>
      );
    }

    if (fetchError) {
      return (
        <div className={styles.searchResults}>
          <Layer>
            <Tile className={styles.emptySearchResultsTile}>
              <EmptyCardIllustration />
              <div>
                <p className={styles.errorMessage}>{t('error', 'Error')}</p>
                <p className={styles.errorCopy}>
                  {t(
                    'errorCopy',
                    'Sorry, there was an error. You can try to reload this page, or contact the site administrator and quote the error code above.',
                  )}
                </p>
              </div>
            </Tile>
          </Layer>
        </div>
      );
    }

    if (searchResults?.length) {
      return (
        <div className={styles.searchResultsContainer}>
          <div className={styles.searchResults}>
            <div className={styles.resultsText}>
              <span className={styles.resultsTextCount}>
                {t('recentSearchResultsCount', '{{count}} recent search result', {
                  count: searchResults.length,
                })}
              </span>
              {isValidating && (
                <span className={styles.validationIcon}>
                  <InlineLoading className={styles.spinner} />
                </span>
              )}
            </div>
            <CompactPatientBanner
              ref={ref}
              patients={searchResults}
              hasMore={hasMore}
              isValidating={isValidating}
              fetchMore={fetchMore}
              virtualize={false}
            />
          </div>
        </div>
      );
    }

    return (
      <div className={styles.searchResultsContainer}>
        <div className={styles.searchResults}>
          <Layer>
            <Tile className={styles.emptySearchResultsTile}>
              <EmptyCardIllustration />
              <p className={styles.emptyResultText}>{t('noRecentlyViewedPatients', 'No recently viewed patients')}</p>
              <p className={styles.actionText}>
                <span>
                  {t('recentPatientsEmptyStateHint', 'Patients you select will appear here for quick access')}
                </span>
              </p>
            </Tile>
          </Layer>
        </div>
      </div>
    );
  },
);

export default RecentlySearchedPatients;
